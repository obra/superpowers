# Furniture Manufacturing Tracker Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a Progressive Web App for tracking furniture manufacturing orders through production stations with barcode scanning, inventory management, and cost tracking.

**Architecture:** Next.js 14 full-stack application with PostgreSQL database, deployed on local network. Simple worker scanning interface, comprehensive admin dashboard with real-time updates.

**Tech Stack:** Next.js 14, React, TypeScript, PostgreSQL, Prisma ORM, Tailwind CSS, QuaggaJS (barcode scanning), Nodemailer, OneDrive API

---

## Phase 1: Project Foundation

### Task 1: Initialize Next.js Project

**Files:**
- Create: `/home/user/furniture-tracker/package.json`
- Create: `/home/user/furniture-tracker/tsconfig.json`
- Create: `/home/user/furniture-tracker/.gitignore`
- Create: `/home/user/furniture-tracker/.env.example`

**Step 1: Initialize Next.js with TypeScript**

Run:
```bash
cd /home/user/furniture-tracker
npx create-next-app@latest . --typescript --tailwind --app --no-src-dir --import-alias "@/*"
```

Expected: Next.js project scaffolded with TypeScript and Tailwind

**Step 2: Install dependencies**

Run:
```bash
npm install @prisma/client prisma
npm install -D @types/node
npm install quagga nodemailer
npm install -D @types/nodemailer
```

**Step 3: Create .env.example**

```bash
cat > .env.example << 'EOF'
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/furniture_tracker"

# Admin Authentication
ADMIN_PASSWORD_HASH=""
SESSION_SECRET=""

# Email Configuration
EMAIL_HOST="smtp.gmail.com"
EMAIL_PORT="587"
EMAIL_USER=""
EMAIL_PASSWORD=""

# OneDrive Configuration
ONEDRIVE_CLIENT_ID=""
ONEDRIVE_CLIENT_SECRET=""
ONEDRIVE_REFRESH_TOKEN=""
EOF
```

**Step 4: Update .gitignore**

Add to `.gitignore`:
```
.env
.env.local
```

**Step 5: Commit**

```bash
git add .
git commit -m "chore: initialize Next.js project with TypeScript and Tailwind"
```

---

### Task 2: Database Schema Setup

**Files:**
- Create: `prisma/schema.prisma`

**Step 1: Initialize Prisma**

Run:
```bash
npx prisma init
```

Expected: Creates `prisma/schema.prisma` and `.env`

**Step 2: Define database schema**

Edit `prisma/schema.prisma`:

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model Station {
  id          String   @id @default(cuid())
  name        String   @unique
  description String?
  laborRate   Float    @default(0) // per hour
  sortOrder   Int      @default(0)
  active      Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  stationLogs StationLog[]

  @@map("stations")
}

model Material {
  id              String   @id @default(cuid())
  name            String   @unique
  type            String   // leather, fabric, wood, hardware
  unitOfMeasure   String   // sheets, yards, pieces
  currentQuantity Float    @default(0)
  unitCost        Float    @default(0)
  reorderThreshold Float   @default(0)
  active          Boolean  @default(true)
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  orderMaterials  OrderMaterial[]
  templateMaterials TemplateMaterial[]

  @@map("materials")
}

model MaterialTemplate {
  id          String   @id @default(cuid())
  name        String   @unique
  description String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  materials   TemplateMaterial[]
  orders      Order[]

  @@map("material_templates")
}

model TemplateMaterial {
  id                String   @id @default(cuid())
  templateId        String
  materialId        String
  plannedQuantity   Float

  template          MaterialTemplate @relation(fields: [templateId], references: [id], onDelete: Cascade)
  material          Material @relation(fields: [materialId], references: [id])

  @@unique([templateId, materialId])
  @@map("template_materials")
}

model Order {
  id                    String   @id @default(cuid())
  orderNumber           String   @unique
  customerName          String
  styleId               String?
  customSpecifications  String?
  status                String   @default("Not Started") // Not Started, In Progress, Completed
  createdAt             DateTime @default(now())
  completedAt           DateTime?
  updatedAt             DateTime @updatedAt

  style                 MaterialTemplate? @relation(fields: [styleId], references: [id])
  materials             OrderMaterial[]
  stationLogs           StationLog[]

  @@map("orders")
}

model OrderMaterial {
  id              String   @id @default(cuid())
  orderId         String
  materialId      String
  plannedQuantity Float
  actualQuantity  Float    @default(0)
  unitCost        Float    // locked at order creation
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  order           Order    @relation(fields: [orderId], references: [id], onDelete: Cascade)
  material        Material @relation(fields: [materialId], references: [id])

  @@unique([orderId, materialId])
  @@map("order_materials")
}

model StationLog {
  id          String    @id @default(cuid())
  orderId     String
  stationId   String
  checkInAt   DateTime  @default(now())
  checkOutAt  DateTime?
  notes       String?

  order       Order     @relation(fields: [orderId], references: [id], onDelete: Cascade)
  station     Station   @relation(fields: [stationId], references: [id])

  @@index([orderId])
  @@index([stationId])
  @@map("station_logs")
}
```

**Step 3: Generate Prisma Client**

Run:
```bash
npx prisma generate
```

Expected: Prisma client generated

**Step 4: Commit**

```bash
git add prisma/schema.prisma
git commit -m "feat: add database schema with Prisma"
```

---

### Task 3: Database Client Setup

**Files:**
- Create: `lib/db.ts`
- Create: `lib/prisma.ts`

**Step 1: Create Prisma singleton**

Create `lib/prisma.ts`:

```typescript
import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const prisma = globalForPrisma.prisma ?? new PrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma
```

**Step 2: Create database helper functions**

Create `lib/db.ts`:

```typescript
import { prisma } from './prisma'

export { prisma }

// Helper to calculate order costs
export async function calculateOrderCosts(orderId: string) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      materials: true,
      stationLogs: {
        include: {
          station: true
        }
      }
    }
  })

  if (!order) return null

  // Calculate material costs
  const materialCost = order.materials.reduce((sum, om) => {
    return sum + (om.actualQuantity * om.unitCost)
  }, 0)

  // Calculate labor costs
  const laborCost = order.stationLogs.reduce((sum, log) => {
    if (!log.checkOutAt) return sum
    const hours = (log.checkOutAt.getTime() - log.checkInAt.getTime()) / (1000 * 60 * 60)
    return sum + (hours * log.station.laborRate)
  }, 0)

  return {
    materialCost,
    laborCost,
    totalCost: materialCost + laborCost
  }
}

// Helper to get current station for an order
export async function getCurrentStation(orderId: string) {
  const latestLog = await prisma.stationLog.findFirst({
    where: {
      orderId,
      checkOutAt: null
    },
    include: {
      station: true
    },
    orderBy: {
      checkInAt: 'desc'
    }
  })

  return latestLog?.station ?? null
}
```

**Step 3: Commit**

```bash
git add lib/
git commit -m "feat: add database client and helper functions"
```

---

## Phase 2: Core API Routes

### Task 4: Stations API

**Files:**
- Create: `app/api/stations/route.ts`
- Create: `app/api/stations/[id]/route.ts`

**Step 1: Write test for GET stations**

Create `__tests__/api/stations.test.ts`:

```typescript
import { describe, it, expect, beforeAll, afterAll } from '@jest/globals'
import { prisma } from '@/lib/prisma'

describe('GET /api/stations', () => {
  beforeAll(async () => {
    await prisma.station.create({
      data: {
        name: 'Test Station',
        description: 'Test',
        laborRate: 25,
        sortOrder: 1
      }
    })
  })

  afterAll(async () => {
    await prisma.station.deleteMany()
  })

  it('returns all active stations', async () => {
    const response = await fetch('http://localhost:3000/api/stations')
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(Array.isArray(data)).toBe(true)
    expect(data.length).toBeGreaterThan(0)
  })
})
```

**Step 2: Run test to verify it fails**

Run: `npm test`
Expected: FAIL (API route doesn't exist)

**Step 3: Implement GET stations**

Create `app/api/stations/route.ts`:

```typescript
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const stations = await prisma.station.findMany({
      where: { active: true },
      orderBy: { sortOrder: 'asc' }
    })
    return NextResponse.json(stations)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch stations' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const station = await prisma.station.create({
      data: {
        name: body.name,
        description: body.description,
        laborRate: body.laborRate,
        sortOrder: body.sortOrder || 0,
      }
    })
    return NextResponse.json(station, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create station' }, { status: 500 })
  }
}
```

**Step 4: Run test to verify it passes**

Run: `npm test`
Expected: PASS

**Step 5: Commit**

```bash
git add app/api/stations/ __tests__/
git commit -m "feat: add stations API endpoints"
```

---

### Task 5: Materials API

**Files:**
- Create: `app/api/materials/route.ts`
- Create: `app/api/materials/[id]/route.ts`

**Step 1: Write test for materials API**

Create `__tests__/api/materials.test.ts`:

```typescript
import { describe, it, expect } from '@jest/globals'

describe('GET /api/materials', () => {
  it('returns all active materials', async () => {
    const response = await fetch('http://localhost:3000/api/materials')
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(Array.isArray(data)).toBe(true)
  })
})
```

**Step 2: Run test to verify failure**

Run: `npm test`
Expected: FAIL

**Step 3: Implement materials API**

Create `app/api/materials/route.ts`:

```typescript
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const materials = await prisma.material.findMany({
      where: { active: true },
      orderBy: { name: 'asc' }
    })
    return NextResponse.json(materials)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch materials' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const material = await prisma.material.create({
      data: {
        name: body.name,
        type: body.type,
        unitOfMeasure: body.unitOfMeasure,
        currentQuantity: body.currentQuantity || 0,
        unitCost: body.unitCost || 0,
        reorderThreshold: body.reorderThreshold || 0,
      }
    })
    return NextResponse.json(material, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create material' }, { status: 500 })
  }
}
```

**Step 4: Run test to verify pass**

Run: `npm test`
Expected: PASS

**Step 5: Commit**

```bash
git add app/api/materials/
git commit -m "feat: add materials API endpoints"
```

---

### Task 6: Orders API

**Files:**
- Create: `app/api/orders/route.ts`
- Create: `app/api/orders/[id]/route.ts`
- Create: `app/api/orders/[id]/costs/route.ts`

**Step 1: Write test for orders API**

Create `__tests__/api/orders.test.ts`:

```typescript
import { describe, it, expect } from '@jest/globals'

describe('POST /api/orders', () => {
  it('creates a new order', async () => {
    const response = await fetch('http://localhost:3000/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customerName: 'Test Customer',
        orderNumber: 'ORD-001'
      })
    })
    const data = await response.json()

    expect(response.status).toBe(201)
    expect(data.customerName).toBe('Test Customer')
  })
})
```

**Step 2: Run test to verify failure**

Run: `npm test`
Expected: FAIL

**Step 3: Implement orders API**

Create `app/api/orders/route.ts`:

```typescript
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const orders = await prisma.order.findMany({
      include: {
        style: true,
        materials: {
          include: {
            material: true
          }
        },
        stationLogs: {
          include: {
            station: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json(orders)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch orders' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Generate unique order number if not provided
    const orderNumber = body.orderNumber || `ORD-${Date.now()}`

    const order = await prisma.order.create({
      data: {
        orderNumber,
        customerName: body.customerName,
        styleId: body.styleId,
        customSpecifications: body.customSpecifications,
      }
    })

    // If materials provided, create order materials
    if (body.materials && body.materials.length > 0) {
      await prisma.orderMaterial.createMany({
        data: body.materials.map((m: any) => ({
          orderId: order.id,
          materialId: m.materialId,
          plannedQuantity: m.quantity,
          unitCost: m.unitCost
        }))
      })
    }

    return NextResponse.json(order, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 })
  }
}
```

**Step 4: Add costs endpoint**

Create `app/api/orders/[id]/costs/route.ts`:

```typescript
import { NextResponse } from 'next/server'
import { calculateOrderCosts } from '@/lib/db'

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const costs = await calculateOrderCosts(params.id)

    if (!costs) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    return NextResponse.json(costs)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to calculate costs' }, { status: 500 })
  }
}
```

**Step 5: Run test to verify pass**

Run: `npm test`
Expected: PASS

**Step 6: Commit**

```bash
git add app/api/orders/
git commit -m "feat: add orders API with cost calculation"
```

---

### Task 7: Scanning API (Check-in/Check-out)

**Files:**
- Create: `app/api/scan/route.ts`

**Step 1: Write test for scan API**

Create `__tests__/api/scan.test.ts`:

```typescript
import { describe, it, expect, beforeAll } from '@jest/globals'
import { prisma } from '@/lib/prisma'

describe('POST /api/scan', () => {
  let orderId: string
  let stationId: string

  beforeAll(async () => {
    const station = await prisma.station.create({
      data: { name: 'Test Station', laborRate: 25 }
    })
    stationId = station.id

    const order = await prisma.order.create({
      data: { orderNumber: 'TEST-001', customerName: 'Test' }
    })
    orderId = order.id
  })

  it('checks in an order to a station', async () => {
    const response = await fetch('http://localhost:3000/api/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderId,
        stationId
      })
    })
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.action).toBe('CHECK_IN')
  })

  it('checks out an order from a station', async () => {
    const response = await fetch('http://localhost:3000/api/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderId,
        stationId
      })
    })
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.action).toBe('CHECK_OUT')
  })
})
```

**Step 2: Run test to verify failure**

Run: `npm test`
Expected: FAIL

**Step 3: Implement scan API with auto-checkout logic**

Create `app/api/scan/route.ts`:

```typescript
import { NextResponse } from 'next/server'
import { prisma, getCurrentStation } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { orderId, stationId } = body

    // Find current station for this order
    const currentStation = await getCurrentStation(orderId)

    // Case 1: Order not at any station -> CHECK IN
    if (!currentStation) {
      const log = await prisma.stationLog.create({
        data: {
          orderId,
          stationId
        }
      })

      // Update order status
      await prisma.order.update({
        where: { id: orderId },
        data: { status: 'In Progress' }
      })

      return NextResponse.json({
        action: 'CHECK_IN',
        log,
        message: `Order checked in to ${stationId}`
      })
    }

    // Case 2: Order at same station -> CHECK OUT
    if (currentStation.id === stationId) {
      const log = await prisma.stationLog.findFirst({
        where: {
          orderId,
          stationId,
          checkOutAt: null
        }
      })

      if (log) {
        const updatedLog = await prisma.stationLog.update({
          where: { id: log.id },
          data: { checkOutAt: new Date() }
        })

        return NextResponse.json({
          action: 'CHECK_OUT',
          log: updatedLog,
          message: `Order checked out from ${currentStation.name}`
        })
      }
    }

    // Case 3: Order at different station -> AUTO CHECK OUT + CHECK IN
    if (currentStation.id !== stationId) {
      // Check out from old station
      const oldLog = await prisma.stationLog.findFirst({
        where: {
          orderId,
          stationId: currentStation.id,
          checkOutAt: null
        }
      })

      if (oldLog) {
        await prisma.stationLog.update({
          where: { id: oldLog.id },
          data: { checkOutAt: new Date() }
        })
      }

      // Check in to new station
      const newLog = await prisma.stationLog.create({
        data: {
          orderId,
          stationId
        }
      })

      return NextResponse.json({
        action: 'TRANSFER',
        log: newLog,
        message: `Order moved from ${currentStation.name} to new station`
      })
    }

    return NextResponse.json({ error: 'Invalid scan state' }, { status: 400 })

  } catch (error) {
    return NextResponse.json({ error: 'Scan failed' }, { status: 500 })
  }
}
```

**Step 4: Run test to verify pass**

Run: `npm test`
Expected: PASS

**Step 5: Commit**

```bash
git add app/api/scan/ __tests__/
git commit -m "feat: add scanning API with auto-checkout logic"
```

---

## Phase 3: Worker Interface

### Task 8: Worker Scanning Page

**Files:**
- Create: `app/station/page.tsx`
- Create: `components/StationScanner.tsx`
- Create: `components/BarcodeScanner.tsx`

**Step 1: Create barcode scanner component**

Create `components/BarcodeScanner.tsx`:

```typescript
'use client'

import { useEffect, useRef, useState } from 'react'
import Quagga from 'quagga'

interface BarcodeScannerProps {
  onScan: (barcode: string) => void
  active: boolean
}

export default function BarcodeScanner({ onScan, active }: BarcodeScannerProps) {
  const scannerRef = useRef<HTMLDivElement>(null)
  const [manualEntry, setManualEntry] = useState(false)
  const [manualCode, setManualCode] = useState('')

  useEffect(() => {
    if (!active || manualEntry) return

    if (scannerRef.current) {
      Quagga.init({
        inputStream: {
          type: 'LiveStream',
          target: scannerRef.current,
          constraints: {
            facingMode: 'environment'
          }
        },
        decoder: {
          readers: ['code_128_reader', 'ean_reader', 'ean_8_reader']
        }
      }, (err) => {
        if (err) {
          console.error('Barcode scanner init error:', err)
          setManualEntry(true)
          return
        }
        Quagga.start()
      })

      Quagga.onDetected((result) => {
        if (result.codeResult.code) {
          onScan(result.codeResult.code)
          Quagga.stop()
        }
      })
    }

    return () => {
      Quagga.stop()
    }
  }, [active, manualEntry, onScan])

  if (manualEntry) {
    return (
      <div className="p-4 space-y-4">
        <input
          type="text"
          value={manualCode}
          onChange={(e) => setManualCode(e.target.value)}
          placeholder="Enter barcode manually"
          className="w-full p-4 text-2xl border-2 rounded"
          autoFocus
        />
        <button
          onClick={() => {
            if (manualCode) {
              onScan(manualCode)
              setManualCode('')
            }
          }}
          className="w-full p-4 text-2xl bg-blue-600 text-white rounded"
        >
          Submit
        </button>
        <button
          onClick={() => setManualEntry(false)}
          className="w-full p-2 text-lg bg-gray-300 rounded"
        >
          Try Camera Again
        </button>
      </div>
    )
  }

  return (
    <div className="relative">
      <div ref={scannerRef} className="w-full h-64 bg-black rounded" />
      <button
        onClick={() => setManualEntry(true)}
        className="mt-4 w-full p-2 bg-gray-300 rounded"
      >
        Enter Manually
      </button>
    </div>
  )
}
```

**Step 2: Create station scanner component**

Create `components/StationScanner.tsx`:

```typescript
'use client'

import { useState, useEffect } from 'react'
import BarcodeScanner from './BarcodeScanner'

interface Station {
  id: string
  name: string
}

interface Order {
  id: string
  orderNumber: string
}

export default function StationScanner() {
  const [currentStation, setCurrentStation] = useState<Station | null>(null)
  const [ordersAtStation, setOrdersAtStation] = useState<Order[]>([])
  const [scanningFor, setScanningFor] = useState<'station' | 'order'>('station')
  const [message, setMessage] = useState<string>('')
  const [messageType, setMessageType] = useState<'success' | 'error'>('success')

  const fetchOrdersAtStation = async (stationId: string) => {
    try {
      const response = await fetch(`/api/stations/${stationId}/orders`)
      const orders = await response.json()
      setOrdersAtStation(orders)
    } catch (error) {
      console.error('Failed to fetch orders:', error)
    }
  }

  const handleStationScan = async (barcode: string) => {
    try {
      const response = await fetch(`/api/stations?barcode=${barcode}`)
      const stations = await response.json()

      if (stations.length > 0) {
        setCurrentStation(stations[0])
        setScanningFor('order')
        await fetchOrdersAtStation(stations[0].id)
        showMessage(`Station: ${stations[0].name}`, 'success')
      } else {
        showMessage('Station not found', 'error')
      }
    } catch (error) {
      showMessage('Failed to scan station', 'error')
    }
  }

  const handleOrderScan = async (barcode: string) => {
    if (!currentStation) return

    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderBarcode: barcode,
          stationId: currentStation.id
        })
      })

      const result = await response.json()

      if (response.ok) {
        showMessage(result.message, 'success')
        await fetchOrdersAtStation(currentStation.id)
      } else {
        showMessage(result.error || 'Scan failed', 'error')
      }
    } catch (error) {
      showMessage('Failed to process scan', 'error')
    }
  }

  const showMessage = (msg: string, type: 'success' | 'error') => {
    setMessage(msg)
    setMessageType(type)
    setTimeout(() => setMessage(''), 3000)
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {/* Header */}
      <div className="bg-white rounded-lg shadow p-6 mb-4">
        {currentStation ? (
          <div className="flex justify-between items-center">
            <h1 className="text-4xl font-bold">🏭 {currentStation.name}</h1>
            <button
              onClick={() => {
                setCurrentStation(null)
                setScanningFor('station')
                setOrdersAtStation([])
              }}
              className="px-4 py-2 bg-gray-300 rounded"
            >
              Change Station
            </button>
          </div>
        ) : (
          <h1 className="text-4xl font-bold text-center">Scan Station Barcode</h1>
        )}
      </div>

      {/* Orders at station */}
      {currentStation && (
        <div className="bg-white rounded-lg shadow p-6 mb-4">
          <h2 className="text-2xl font-semibold mb-4">Orders at this station:</h2>
          {ordersAtStation.length === 0 ? (
            <p className="text-gray-500 text-xl">No orders currently</p>
          ) : (
            <ul className="space-y-2">
              {ordersAtStation.map(order => (
                <li key={order.id} className="text-2xl">• Order {order.orderNumber}</li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* Scanner */}
      <div className="bg-white rounded-lg shadow p-6 mb-4">
        <h2 className="text-2xl font-semibold mb-4">
          {scanningFor === 'station' ? 'SCAN STATION' : 'SCAN ORDER BARCODE'}
        </h2>
        <BarcodeScanner
          onScan={scanningFor === 'station' ? handleStationScan : handleOrderScan}
          active={true}
        />
      </div>

      {/* Message */}
      {message && (
        <div className={`fixed top-0 left-0 right-0 p-8 text-center text-white text-3xl font-bold ${
          messageType === 'success' ? 'bg-green-600' : 'bg-red-600'
        }`}>
          {messageType === 'success' ? '✅' : '❌'} {message}
        </div>
      )}
    </div>
  )
}
```

**Step 3: Create station page**

Create `app/station/page.tsx`:

```typescript
import StationScanner from '@/components/StationScanner'

export default function StationPage() {
  return <StationScanner />
}
```

**Step 4: Test manually**

Run:
```bash
npm run dev
```

Visit: `http://localhost:3000/station`
Expected: Station scanning interface loads

**Step 5: Commit**

```bash
git add app/station/ components/
git commit -m "feat: add worker station scanning interface"
```

---

## Phase 4: Admin Dashboard

### Task 9: Admin Layout and Navigation

**Files:**
- Create: `app/admin/layout.tsx`
- Create: `app/admin/page.tsx`
- Create: `components/AdminNav.tsx`

**Step 1: Create admin navigation**

Create `components/AdminNav.tsx`:

```typescript
'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function AdminNav() {
  const pathname = usePathname()

  const links = [
    { href: '/admin', label: 'Floor View' },
    { href: '/admin/orders', label: 'Orders' },
    { href: '/admin/inventory', label: 'Inventory' },
    { href: '/admin/reports', label: 'Reports' },
    { href: '/admin/settings', label: 'Settings' },
  ]

  return (
    <nav className="bg-blue-900 text-white">
      <div className="container mx-auto flex gap-1 p-2">
        {links.map(link => (
          <Link
            key={link.href}
            href={link.href}
            className={`px-4 py-2 rounded ${
              pathname === link.href ? 'bg-blue-700' : 'hover:bg-blue-800'
            }`}
          >
            {link.label}
          </Link>
        ))}
      </div>
    </nav>
  )
}
```

**Step 2: Create admin layout**

Create `app/admin/layout.tsx`:

```typescript
import AdminNav from '@/components/AdminNav'

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-gray-50">
      <AdminNav />
      <main className="container mx-auto p-6">
        {children}
      </main>
    </div>
  )
}
```

**Step 3: Create floor view dashboard**

Create `app/admin/page.tsx`:

```typescript
'use client'

import { useEffect, useState } from 'react'

interface Station {
  id: string
  name: string
}

interface Order {
  id: string
  orderNumber: string
  customerName: string
}

interface FloorData {
  [stationId: string]: {
    station: Station
    orders: (Order & { timeAtStation: number })[]
  }
}

export default function AdminDashboard() {
  const [floorData, setFloorData] = useState<FloorData>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchFloorView()
    const interval = setInterval(fetchFloorView, 5000) // Refresh every 5 seconds
    return () => clearInterval(interval)
  }, [])

  const fetchFloorView = async () => {
    try {
      const response = await fetch('/api/floor-view')
      const data = await response.json()
      setFloorData(data)
      setLoading(false)
    } catch (error) {
      console.error('Failed to fetch floor view:', error)
    }
  }

  const getColorClass = (hours: number) => {
    if (hours < 4) return 'bg-green-100 border-green-400'
    if (hours < 8) return 'bg-yellow-100 border-yellow-400'
    return 'bg-red-100 border-red-400'
  }

  if (loading) {
    return <div className="text-center p-8">Loading...</div>
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Live Floor View</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.values(floorData).map(({ station, orders }) => (
          <div key={station.id} className="bg-white rounded-lg shadow p-6">
            <h2 className="text-2xl font-semibold mb-4 border-b pb-2">
              {station.name}
            </h2>

            {orders.length === 0 ? (
              <p className="text-gray-400 italic">No orders</p>
            ) : (
              <div className="space-y-2">
                {orders.map(order => (
                  <div
                    key={order.id}
                    className={`p-3 border-2 rounded ${getColorClass(order.timeAtStation)}`}
                  >
                    <div className="font-semibold">{order.orderNumber}</div>
                    <div className="text-sm text-gray-600">{order.customerName}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {order.timeAtStation.toFixed(1)}h
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
```

**Step 4: Test manually**

Run: `npm run dev`
Visit: `http://localhost:3000/admin`
Expected: Admin dashboard loads

**Step 5: Commit**

```bash
git add app/admin/ components/AdminNav.tsx
git commit -m "feat: add admin dashboard with floor view"
```

---

### Task 10: Floor View API

**Files:**
- Create: `app/api/floor-view/route.ts`

**Step 1: Implement floor view API**

Create `app/api/floor-view/route.ts`:

```typescript
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const stations = await prisma.station.findMany({
      where: { active: true },
      orderBy: { sortOrder: 'asc' },
      include: {
        stationLogs: {
          where: {
            checkOutAt: null
          },
          include: {
            order: true
          }
        }
      }
    })

    const floorData = stations.reduce((acc, station) => {
      acc[station.id] = {
        station: {
          id: station.id,
          name: station.name
        },
        orders: station.stationLogs.map(log => {
          const hours = (Date.now() - log.checkInAt.getTime()) / (1000 * 60 * 60)
          return {
            id: log.order.id,
            orderNumber: log.order.orderNumber,
            customerName: log.order.customerName,
            timeAtStation: hours
          }
        })
      }
      return acc
    }, {} as any)

    return NextResponse.json(floorData)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch floor view' }, { status: 500 })
  }
}
```

**Step 2: Commit**

```bash
git add app/api/floor-view/
git commit -m "feat: add floor view API endpoint"
```

---

## Phase 5: Additional Features

### Task 11: Orders Management Page

**Files:**
- Create: `app/admin/orders/page.tsx`
- Create: `components/OrderForm.tsx`

**Step 1: Create order form component**

Create `components/OrderForm.tsx`:

```typescript
'use client'

import { useState, useEffect } from 'react'

interface Material {
  id: string
  name: string
  unitCost: number
}

interface OrderFormProps {
  onSubmit: (order: any) => void
  onCancel: () => void
}

export default function OrderForm({ onSubmit, onCancel }: OrderFormProps) {
  const [materials, setMaterials] = useState<Material[]>([])
  const [customerName, setCustomerName] = useState('')
  const [orderNumber, setOrderNumber] = useState('')
  const [selectedMaterials, setSelectedMaterials] = useState<any[]>([])

  useEffect(() => {
    fetch('/api/materials')
      .then(res => res.json())
      .then(setMaterials)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      customerName,
      orderNumber,
      materials: selectedMaterials
    })
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-6 space-y-4">
      <h2 className="text-2xl font-bold">Create New Order</h2>

      <div>
        <label className="block text-sm font-medium mb-1">Order Number</label>
        <input
          type="text"
          value={orderNumber}
          onChange={(e) => setOrderNumber(e.target.value)}
          className="w-full border rounded p-2"
          placeholder="Auto-generated if empty"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Customer Name</label>
        <input
          type="text"
          value={customerName}
          onChange={(e) => setCustomerName(e.target.value)}
          className="w-full border rounded p-2"
          required
        />
      </div>

      <div className="flex gap-2">
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">
          Create Order
        </button>
        <button type="button" onClick={onCancel} className="px-4 py-2 bg-gray-300 rounded">
          Cancel
        </button>
      </div>
    </form>
  )
}
```

**Step 2: Create orders management page**

Create `app/admin/orders/page.tsx`:

```typescript
'use client'

import { useEffect, useState } from 'react'
import OrderForm from '@/components/OrderForm'

interface Order {
  id: string
  orderNumber: string
  customerName: string
  status: string
  createdAt: string
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [showForm, setShowForm] = useState(false)

  useEffect(() => {
    fetchOrders()
  }, [])

  const fetchOrders = async () => {
    const response = await fetch('/api/orders')
    const data = await response.json()
    setOrders(data)
  }

  const handleCreateOrder = async (orderData: any) => {
    const response = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    })

    if (response.ok) {
      setShowForm(false)
      fetchOrders()
    }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Orders</h1>
        <button
          onClick={() => setShowForm(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded"
        >
          + New Order
        </button>
      </div>

      {showForm && (
        <div className="mb-6">
          <OrderForm
            onSubmit={handleCreateOrder}
            onCancel={() => setShowForm(false)}
          />
        </div>
      )}

      <div className="bg-white rounded-lg shadow">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="p-4 text-left">Order #</th>
              <th className="p-4 text-left">Customer</th>
              <th className="p-4 text-left">Status</th>
              <th className="p-4 text-left">Created</th>
              <th className="p-4 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(order => (
              <tr key={order.id} className="border-b hover:bg-gray-50">
                <td className="p-4">{order.orderNumber}</td>
                <td className="p-4">{order.customerName}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded text-sm ${
                    order.status === 'Completed' ? 'bg-green-100' :
                    order.status === 'In Progress' ? 'bg-blue-100' :
                    'bg-gray-100'
                  }`}>
                    {order.status}
                  </span>
                </td>
                <td className="p-4">{new Date(order.createdAt).toLocaleDateString()}</td>
                <td className="p-4">
                  <button className="text-blue-600 hover:underline">View</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
```

**Step 3: Commit**

```bash
git add app/admin/orders/ components/OrderForm.tsx
git commit -m "feat: add orders management page"
```

---

### Task 12: Inventory Management Page

**Files:**
- Create: `app/admin/inventory/page.tsx`

**Step 1: Create inventory page**

Create `app/admin/inventory/page.tsx`:

```typescript
'use client'

import { useEffect, useState } from 'react'

interface Material {
  id: string
  name: string
  type: string
  currentQuantity: number
  unitCost: number
  reorderThreshold: number
  unitOfMeasure: string
}

export default function InventoryPage() {
  const [materials, setMaterials] = useState<Material[]>([])

  useEffect(() => {
    fetchMaterials()
  }, [])

  const fetchMaterials = async () => {
    const response = await fetch('/api/materials')
    const data = await response.json()
    setMaterials(data)
  }

  const isLowStock = (material: Material) => {
    return material.currentQuantity <= material.reorderThreshold
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Inventory</h1>

      <div className="bg-white rounded-lg shadow">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="p-4 text-left">Material</th>
              <th className="p-4 text-left">Type</th>
              <th className="p-4 text-left">Quantity</th>
              <th className="p-4 text-left">Unit Cost</th>
              <th className="p-4 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {materials.map(material => (
              <tr
                key={material.id}
                className={`border-b hover:bg-gray-50 ${
                  isLowStock(material) ? 'bg-red-50' : ''
                }`}
              >
                <td className="p-4 font-medium">{material.name}</td>
                <td className="p-4">{material.type}</td>
                <td className="p-4">
                  {material.currentQuantity} {material.unitOfMeasure}
                </td>
                <td className="p-4">${material.unitCost.toFixed(2)}</td>
                <td className="p-4">
                  {isLowStock(material) && (
                    <span className="px-2 py-1 bg-red-100 text-red-800 rounded text-sm">
                      ⚠️ Low Stock
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
```

**Step 2: Commit**

```bash
git add app/admin/inventory/
git commit -m "feat: add inventory management page"
```

---

## Phase 6: Testing & Deployment

### Task 13: Setup Testing Framework

**Files:**
- Create: `jest.config.js`
- Create: `jest.setup.js`
- Update: `package.json`

**Step 1: Install testing dependencies**

Run:
```bash
npm install -D jest @jest/globals @testing-library/react @testing-library/jest-dom jest-environment-jsdom
```

**Step 2: Create Jest configuration**

Create `jest.config.js`:

```javascript
const nextJest = require('next/jest')

const createJestConfig = nextJest({
  dir: './',
})

const customJestConfig = {
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  testEnvironment: 'jest-environment-jsdom',
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/$1',
  },
}

module.exports = createJestConfig(customJestConfig)
```

Create `jest.setup.js`:

```javascript
import '@testing-library/jest-dom'
```

**Step 3: Add test script to package.json**

Update `package.json`:

```json
{
  "scripts": {
    "test": "jest",
    "test:watch": "jest --watch"
  }
}
```

**Step 4: Commit**

```bash
git add jest.config.js jest.setup.js package.json
git commit -m "chore: setup testing framework with Jest"
```

---

### Task 14: Create Deployment Documentation

**Files:**
- Create: `README.md`
- Create: `DEPLOYMENT.md`

**Step 1: Create README**

Create `README.md`:

```markdown
# Furniture Manufacturing Tracker

Progressive Web App for tracking furniture manufacturing work-in-progress with barcode scanning.

## Features

- Barcode scanning at workstations (camera or handheld scanner)
- Real-time floor view dashboard
- Order and inventory management
- Time and cost tracking per station
- Email and OneDrive report integration

## Tech Stack

- Next.js 14
- PostgreSQL
- Prisma ORM
- Tailwind CSS
- QuaggaJS (barcode scanning)

## Quick Start

1. Install dependencies:
```bash
npm install
```

2. Set up database:
```bash
cp .env.example .env
# Edit .env with your database credentials
npx prisma migrate dev
npx prisma generate
```

3. Run development server:
```bash
npm run dev
```

4. Access:
- Worker interface: http://localhost:3000/station
- Admin dashboard: http://localhost:3000/admin

## Documentation

See [DEPLOYMENT.md](./DEPLOYMENT.md) for production deployment instructions.
```

**Step 2: Create deployment guide**

Create `DEPLOYMENT.md`:

```markdown
# Deployment Guide

## Prerequisites

- Node.js 18+ installed
- PostgreSQL 15+ installed and running
- Local network access

## Installation Steps

### 1. Clone and Install

```bash
git clone <repository-url>
cd furniture-tracker
npm install
```

### 2. Database Setup

```bash
# Create PostgreSQL database
createdb furniture_tracker

# Copy environment template
cp .env.example .env
```

Edit `.env`:

```
DATABASE_URL="postgresql://username:password@localhost:5432/furniture_tracker"
ADMIN_PASSWORD_HASH="<generate-hash>"
SESSION_SECRET="<random-string>"
```

Generate admin password hash:

```bash
node -e "console.log(require('bcrypt').hashSync('your-password', 10))"
```

### 3. Run Migrations

```bash
npx prisma migrate deploy
npx prisma generate
```

### 4. Seed Initial Data

Create 3 stations:

```bash
node scripts/seed-stations.js
```

### 5. Build and Start

```bash
npm run build
npm start
```

Application runs on port 3000.

### 6. Access on Local Network

Find server IP:

```bash
ifconfig | grep inet
```

Workers access: `http://192.168.x.x:3000/station`
Admin access: `http://192.168.x.x:3000/admin`

## Barcode Setup

1. Generate station barcodes (Code 128 format)
2. Print and laminate
3. Post at each workstation

Order barcodes are auto-generated when orders are created.

## Email Configuration

For Gmail:
1. Enable 2-factor authentication
2. Create app password
3. Add to .env:

```
EMAIL_HOST="smtp.gmail.com"
EMAIL_PORT="587"
EMAIL_USER="your-email@gmail.com"
EMAIL_PASSWORD="app-password"
```

## OneDrive Configuration

1. Register app at https://portal.azure.com
2. Get client ID and secret
3. Generate refresh token
4. Add to .env

## Backups

Automated daily backups:

```bash
# Add to crontab
0 2 * * * pg_dump furniture_tracker > /backups/furniture_tracker_$(date +\%Y\%m\%d).sql
```

## Troubleshooting

### Database connection fails
- Check PostgreSQL is running: `sudo service postgresql status`
- Verify DATABASE_URL in .env

### Barcode scanning doesn't work
- Grant camera permissions in browser
- Use manual entry as fallback
- Verify QuaggaJS loaded correctly

### Can't access from other devices
- Check firewall allows port 3000
- Verify devices on same network
- Use server's local IP address
```

**Step 3: Commit**

```bash
git add README.md DEPLOYMENT.md
git commit -m "docs: add README and deployment documentation"
```

---

## Task 15: Create Initial Migration

**Files:**
- Create: `prisma/migrations/...`

**Step 1: Create initial migration**

Run:
```bash
npx prisma migrate dev --name init
```

Expected: Migration files created

**Step 2: Commit**

```bash
git add prisma/migrations/
git commit -m "chore: add initial database migration"
```

---

## Task 16: Add Seed Script

**Files:**
- Create: `scripts/seed-stations.js`

**Step 1: Create seed script**

Create `scripts/seed-stations.js`:

```javascript
const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function main() {
  const stations = [
    { name: 'Cutting', description: 'Cut materials to size', laborRate: 25, sortOrder: 1 },
    { name: 'Assembly', description: 'Assemble furniture pieces', laborRate: 30, sortOrder: 2 },
    { name: 'Finishing', description: 'Final touches and quality check', laborRate: 35, sortOrder: 3 },
  ]

  for (const station of stations) {
    await prisma.station.upsert({
      where: { name: station.name },
      update: {},
      create: station
    })
  }

  console.log('✓ Seeded 3 stations')

  // Add sample materials
  const materials = [
    { name: 'Oak Plywood 4x8', type: 'wood', unitOfMeasure: 'sheets', currentQuantity: 50, unitCost: 45, reorderThreshold: 10 },
    { name: 'Italian Leather - Brown', type: 'leather', unitOfMeasure: 'yards', currentQuantity: 100, unitCost: 25, reorderThreshold: 20 },
    { name: 'Upholstery Fabric - Gray', type: 'fabric', unitOfMeasure: 'yards', currentQuantity: 75, unitCost: 15, reorderThreshold: 15 },
  ]

  for (const material of materials) {
    await prisma.material.upsert({
      where: { name: material.name },
      update: {},
      create: material
    })
  }

  console.log('✓ Seeded 3 materials')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
```

**Step 2: Run seed script**

Run:
```bash
node scripts/seed-stations.js
```

Expected: 3 stations and 3 materials created

**Step 3: Commit**

```bash
git add scripts/
git commit -m "chore: add database seed script"
```

---

## Summary

This plan creates a fully functional furniture manufacturing tracker with:

✅ Database schema with Prisma ORM
✅ Core API endpoints (stations, materials, orders, scanning)
✅ Worker scanning interface (simple, barcode-enabled)
✅ Admin dashboard (floor view, orders, inventory)
✅ Auto-checkout logic when orders move stations
✅ Cost tracking (materials + labor)
✅ Testing framework
✅ Deployment documentation

## Next Steps After Implementation

1. Add authentication for admin dashboard
2. Implement email reporting
3. Add OneDrive integration
4. Create barcode generation utility
5. Add material templates UI
6. Implement reports page
7. Add PWA manifest for installability
8. Setup production environment

---

**Total Tasks:** 16
**Estimated Time:** 8-12 hours of focused implementation
**Testing Strategy:** TDD throughout, manual testing for UI components
