/**
 * @jest-environment node
 */
import { describe, it, expect, beforeAll, afterAll } from '@jest/globals'
import { prisma } from '../../lib/prisma'
import { GET, POST } from '@/app/api/materials/route'
import { GET as getById, PUT, DELETE } from '@/app/api/materials/[id]/route'

describe('Materials API', () => {
  let testMaterialId: string

  beforeAll(async () => {
    const material = await prisma.material.create({
      data: {
        name: 'Test Leather Material',
        type: 'leather',
        unitOfMeasure: 'sheets',
        currentQuantity: 100,
        unitCost: 50.5,
        reorderThreshold: 20
      }
    })
    testMaterialId = material.id
  })

  afterAll(async () => {
    await prisma.material.deleteMany({
      where: {
        OR: [
          { id: testMaterialId },
          { name: { startsWith: 'Test ' } }
        ]
      }
    })
  })

  describe('GET /api/materials', () => {
    it('returns all active materials', async () => {
      const response = await GET()
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(Array.isArray(data)).toBe(true)
      expect(data.length).toBeGreaterThan(0)
    })
  })

  describe('POST /api/materials', () => {
    it('creates a new material with valid data', async () => {
      const request = new Request('http://localhost:3000/api/materials', {
        method: 'POST',
        body: JSON.stringify({
          name: 'Test Fabric Material',
          type: 'fabric',
          unitOfMeasure: 'yards',
          currentQuantity: 200,
          unitCost: 25.75,
          reorderThreshold: 50
        })
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(201)
      expect(data.name).toBe('Test Fabric Material')
      expect(data.type).toBe('fabric')
      expect(data.unitOfMeasure).toBe('yards')
      expect(data.currentQuantity).toBe(200)
    })

    it('rejects invalid data', async () => {
      const request = new Request('http://localhost:3000/api/materials', {
        method: 'POST',
        body: JSON.stringify({
          name: '',
          type: 'fabric'
        })
      })

      const response = await POST(request)
      expect(response.status).toBe(400)
    })

    it('rejects negative currentQuantity', async () => {
      const request = new Request('http://localhost:3000/api/materials', {
        method: 'POST',
        body: JSON.stringify({
          name: 'Test Material Negative',
          type: 'wood',
          unitOfMeasure: 'pieces',
          currentQuantity: -5
        })
      })

      const response = await POST(request)
      expect(response.status).toBe(400)
    })
  })

  describe('GET /api/materials/[id]', () => {
    it('returns a material by id', async () => {
      const response = await getById(
        new Request(`http://localhost:3000/api/materials/${testMaterialId}`),
        { params: Promise.resolve({ id: testMaterialId }) }
      )
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data.id).toBe(testMaterialId)
      expect(data.name).toBe('Test Leather Material')
    })

    it('returns 404 for non-existent material', async () => {
      const response = await getById(
        new Request('http://localhost:3000/api/materials/invalid-id'),
        { params: Promise.resolve({ id: 'invalid-id' }) }
      )

      expect(response.status).toBe(404)
    })
  })

  describe('PUT /api/materials/[id]', () => {
    it('updates a material', async () => {
      const request = new Request(`http://localhost:3000/api/materials/${testMaterialId}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: 'Test Leather Material Updated',
          type: 'leather',
          unitOfMeasure: 'sheets',
          currentQuantity: 150
        })
      })

      const response = await PUT(
        request,
        { params: Promise.resolve({ id: testMaterialId }) }
      )
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data.name).toBe('Test Leather Material Updated')
      expect(data.currentQuantity).toBe(150)
    })

    it('returns 404 when updating non-existent material', async () => {
      const request = new Request('http://localhost:3000/api/materials/invalid-id', {
        method: 'PUT',
        body: JSON.stringify({
          name: 'Does Not Exist',
          type: 'leather',
          unitOfMeasure: 'sheets'
        })
      })

      const response = await PUT(
        request,
        { params: Promise.resolve({ id: 'invalid-id' }) }
      )

      expect(response.status).toBe(404)
    })
  })

  describe('DELETE /api/materials/[id]', () => {
    it('soft deletes a material', async () => {
      const material = await prisma.material.create({
        data: {
          name: 'Test Material To Delete',
          type: 'hardware',
          unitOfMeasure: 'pieces'
        }
      })

      const response = await DELETE(
        new Request(`http://localhost:3000/api/materials/${material.id}`),
        { params: Promise.resolve({ id: material.id }) }
      )

      expect(response.status).toBe(204)

      const deleted = await prisma.material.findUnique({
        where: { id: material.id }
      })
      expect(deleted?.active).toBe(false)
    })

    it('returns 404 when deleting non-existent material', async () => {
      const response = await DELETE(
        new Request('http://localhost:3000/api/materials/invalid-id'),
        { params: Promise.resolve({ id: 'invalid-id' }) }
      )

      expect(response.status).toBe(404)
    })
  })
})
