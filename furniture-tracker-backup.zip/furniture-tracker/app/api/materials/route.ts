import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const createMaterialSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  type: z.string().min(1, 'Type is required'),
  unitOfMeasure: z.string().min(1, 'Unit of measure is required'),
  currentQuantity: z.number().min(0, 'Current quantity must be >= 0').optional(),
  unitCost: z.number().min(0, 'Unit cost must be >= 0').optional(),
  reorderThreshold: z.number().min(0, 'Reorder threshold must be >= 0').optional(),
})

export async function GET() {
  try {
    const materials = await prisma.material.findMany({
      where: { active: true },
      orderBy: { name: 'asc' }
    })
    return NextResponse.json(materials)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch materials' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const validated = createMaterialSchema.parse(body)

    const material = await prisma.material.create({
      data: {
        name: validated.name,
        type: validated.type,
        unitOfMeasure: validated.unitOfMeasure,
        currentQuantity: validated.currentQuantity ?? 0,
        unitCost: validated.unitCost ?? 0,
        reorderThreshold: validated.reorderThreshold ?? 0,
      }
    })
    return NextResponse.json(material, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues }, { status: 400 })
    }
    return NextResponse.json({ error: 'Failed to create material' }, { status: 500 })
  }
}
