import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const updateMaterialSchema = z.object({
  name: z.string().min(1, 'Name is required').optional(),
  type: z.string().min(1, 'Type is required').optional(),
  unitOfMeasure: z.string().min(1, 'Unit of measure is required').optional(),
  currentQuantity: z.number().min(0, 'Current quantity must be >= 0').optional(),
  unitCost: z.number().min(0, 'Unit cost must be >= 0').optional(),
  reorderThreshold: z.number().min(0, 'Reorder threshold must be >= 0').optional(),
})

type RouteContext = {
  params: Promise<{ id: string }>
}

export async function GET(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params
    const material = await prisma.material.findUnique({
      where: { id }
    })

    if (!material) {
      return NextResponse.json({ error: 'Material not found' }, { status: 404 })
    }

    return NextResponse.json(material)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch material' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params
    const body = await request.json()
    const validated = updateMaterialSchema.parse(body)

    const material = await prisma.material.update({
      where: { id },
      data: validated
    })

    return NextResponse.json(material)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues }, { status: 400 })
    }
    // Prisma will throw if record not found
    if ((error as any).code === 'P2025') {
      return NextResponse.json({ error: 'Material not found' }, { status: 404 })
    }
    return NextResponse.json({ error: 'Failed to update material' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params

    // Soft delete by setting active to false
    await prisma.material.update({
      where: { id },
      data: { active: false }
    })

    return new NextResponse(null, { status: 204 })
  } catch (error) {
    // Prisma will throw if record not found
    if ((error as any).code === 'P2025') {
      return NextResponse.json({ error: 'Material not found' }, { status: 404 })
    }
    return NextResponse.json({ error: 'Failed to delete material' }, { status: 500 })
  }
}
