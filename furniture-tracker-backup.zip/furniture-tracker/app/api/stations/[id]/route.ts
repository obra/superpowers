import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const updateStationSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  laborRate: z.number().min(0).optional(),
  sortOrder: z.number().int().min(0).optional(),
  active: z.boolean().optional(),
})

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  try {
    const station = await prisma.station.findUnique({
      where: { id }
    })

    if (!station) {
      return NextResponse.json({ error: 'Station not found' }, { status: 404 })
    }

    return NextResponse.json(station)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch station' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  try {
    const body = await request.json()
    const validated = updateStationSchema.parse(body)
    const updateData = Object.fromEntries(
      Object.entries(validated).filter(([_, v]) => v !== undefined)
    )

    const station = await prisma.station.update({
      where: { id },
      data: updateData
    })
    return NextResponse.json(station)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues }, { status: 400 })
    }
    return NextResponse.json({ error: 'Failed to update station' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    await prisma.station.update({
      where: { id },
      data: { active: false }
    })
    return new NextResponse(null, { status: 204 })
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'P2025') {
      return NextResponse.json({ error: 'Station not found' }, { status: 404 })
    }
    return NextResponse.json({ error: 'Failed to delete station' }, { status: 500 })
  }
}
